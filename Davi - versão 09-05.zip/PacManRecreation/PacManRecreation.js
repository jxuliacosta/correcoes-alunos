const mazeMap = [
  [4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4],
  [4,1,1,1,1,1,1,1,4,4,4,4,1,1,1,1,1,1,1,4],
  [4,1,4,4,1,4,4,1,4,4,4,4,1,4,4,1,4,4,1,4],
  [4,2,4,4,1,4,4,1,1,1,1,1,1,4,4,1,4,4,2,4],
  [4,1,4,4,1,4,4,1,4,4,4,4,1,4,4,1,4,4,1,4],
  [4,1,1,1,1,1,1,1,0,0,0,0,1,1,1,1,1,1,1,4],
  [4,4,4,1,4,4,1,4,4,0,0,4,4,1,4,4,1,4,4,4],
  [0,1,1,1,4,4,1,4,3,3,3,3,4,1,4,4,1,1,1,0],
  [4,4,4,1,4,4,1,4,4,4,4,4,4,1,4,4,1,4,4,4],
  [4,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,4],
  [4,1,4,1,4,1,4,4,4,4,4,4,4,4,1,4,1,4,1,4],
  [4,2,1,1,4,1,1,1,1,4,4,1,1,1,1,4,1,1,2,4],
  [4,1,4,4,4,1,4,4,1,4,4,1,4,4,1,4,4,4,1,4],
  [4,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,4],
  [4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4]
];

const container = document.getElementById("game-container");
const pacman = document.getElementById("pacman");
let pacX = 1;
let pacY = 1;
let direction = 'right';
let currentSpriteIndex = 0;
let isDead = false;
pacman.style.left = pacX * 31 + "px";
pacman.style.top = pacY * 31 + "px";
pacman.setAttribute('left', pacX * 31 + "px");
pacman.setAttribute('top', pacY * 31 + "px");

let pacmanSprites = {
  up: ['./Sprite/PacMan/Eating/Up/UpEatFrame1.png', './Sprite/PacMan/Eating/Up/UpEatFrame2.png', './Sprite/PacMan/Eating/Up/UpEatFrame3.png'],
  down: ['./Sprite/PacMan/Eating/Down/DownEatFrame1.png', './Sprite/PacMan/Eating/Down/DownEatFrame2.png', './Sprite/PacMan/Eating/Down/DownEatFrame3.png'],
  left: ['./Sprite/PacMan/Eating/Left/LeftEatFrame1.png', './Sprite/PacMan/Eating/Left/LeftEatFrame2.png', './Sprite/PacMan/Eating/Left/LeftEatFrame3.png'],
  right: ['./Sprite/PacMan/Eating/Right/RightEatFrame1.png', './Sprite/PacMan/Eating/Right/RightEatFrame2.png', './Sprite/PacMan/Eating/Right/RightEatFrame3.png'],
  dying: [
    './Sprite/PacMan/Dying/DieFrame1.png', './Sprite/PacMan/Dying/DieFrame2.png', './Sprite/PacMan/Dying/DieFrame3.png',
    './Sprite/PacMan/Dying/DieFrame4.png', './Sprite/PacMan/Dying/DieFrame5.png', './Sprite/PacMan/Dying/DieFrame6.png',
    './Sprite/PacMan/Dying/DieFrame7.png', './Sprite/PacMan/Dying/DieFrame8.png', './Sprite/PacMan/Dying/DieFrame9.png',
    './Sprite/PacMan/Dying/DieFrame10.png', './Sprite/PacMan/Dying/DieFrame11.png'
  ]
};

function createGhost(name, index) {
  const ghost = document.createElement("div");
  ghost.id = name;
  ghost.classList.add("ghost");
  const ghostZones = document.querySelectorAll(".tile.ghost-zone");
  const targetCell = ghostZones[index];
  if (targetCell) {
    targetCell.appendChild(ghost);
  } else {
    console.warn(`ghost-zone[${index}] não encontrada para ${name}`);
  }
  return ghost;
}
function getValidZonesFromDOM(ghostZones) {
  const validZones = [];
  ghostZones.forEach((tile, i) => {
    const x = Math.floor(tile.offsetTop / 31) * 31;
    const y = Math.floor(tile.offsetLeft / 31) * 31;
    validZones.push({ x, y, index: i, element: tile });
  });
  return validZones;
}
let ghostPositions = {
  blinky: [],
  pinky: [],
  inky: [],
  clyde: []
};

let ghostInGhostZone = {
  blinky: true,
  pinky: true,
  inky: true,
  clyde: true
};

function moveGhosts(ghostZones) {
  const validZones = getValidZonesFromDOM(ghostZones);
  const ghostNames = ["blinky", "pinky", "inky", "clyde"];
  if (isDead) return;
  ghostNames.forEach(name => {
    const ghostElement = document.getElementById(name);
    if (!ghostElement || !ghostElement.parentElement) return;
    const parentTile = ghostElement.parentElement;
    const x = Math.floor(parentTile.offsetTop / 31) * 31;
    const y = Math.floor(parentTile.offsetLeft / 31) * 31;
    if (ghostElement.offsetTop === pacman.offsetTop && ghostElement.offsetLeft === pacman.offsetLeft) {
      isDead = true;
      setTimeout(() => {
        resetGame();
      }, 5000);
      return;
    }
    function getNeighbors(x, y) {
      const directions = [
        { dx: -31, dy: 0 },
        { dx: 31, dy: 0 },
        { dx: 0, dy: -31 },
        { dx: 0, dy: 31 }
      ];
      return directions
        .map(({ dx, dy }) => {
          const nx = x + dx;
          const ny = y + dy;
          const zone = validZones.find(zone => zone.x === nx && zone.y === ny);
          if (!zone) return null;
          const isGhostZone = zone.element.classList.contains('ghost-zone');
          if (ghostInGhostZone[name]) {
            return isGhostZone ? null : zone;
          } else {
            return isGhostZone ? null : zone;
          }
        })
        .filter(Boolean);
    }
    const lastPositions = ghostPositions[name];
    const neighbors = getNeighbors(x, y).filter(zone => {
      return !lastPositions.some(pos => pos.x === zone.x && pos.y === zone.y);
    });
    if (neighbors.length > 0) {
      const target = neighbors[Math.floor(Math.random() * neighbors.length)];
      target.element.appendChild(ghostElement);
      lastPositions.push({ x, y });
      if (lastPositions.length > 2) lastPositions.shift();
      ghostInGhostZone[name] = false;
    }
  });
}

let ghostZones;

document.addEventListener("DOMContentLoaded", () => {
  createGhost("blinky", 1);
  createGhost("pinky", 1);
  createGhost("inky", 2);
  createGhost("clyde", 2);
  ghostZones = document.querySelectorAll(".tile.empty, .tile.pellet, .tile.power-pellet, .tile.ghost-zone");
  ghostInterval = setInterval(() => moveGhosts(ghostZones), 800);
});

let ghostInterval;

function checkCollisionGhosts() {
  if (isDead) return;
  const ghostElements = document.querySelectorAll('.ghost');
  ghostElements.forEach(ghost => {
    const ghostX = Math.floor(ghost.offsetLeft / 31);
    const ghostY = Math.floor(ghost.offsetTop / 31);
    if (pacX === ghostX && pacY === ghostY) {
      isDead = true;
      animateDeath();
      clearInterval(ghostInterval);
      setTimeout(() => {
        resetGame();
        ghostInterval = setInterval(() => moveGhosts(ghostZones), 800);
      }, 2000);
    }
  });
}

mazeMap.forEach((row, y) => {
  row.forEach((cell, x) => {
    const tile = document.createElement("div");
    tile.classList.add("tile");
    switch (cell) {
      case 0:
        tile.classList.add("empty");
        break;
      case 1:
        tile.classList.add("pellet");
        break;
      case 2:
        tile.classList.add("power-pellet");
        break;
      case 3:
        tile.classList.add("ghost-zone");
        break;
      case 4:
        tile.classList.add("wall");
        break;
    }
    tile.style.left = x * 31 + "px";
    tile.style.top = y * 31 + "px";
    tile.setAttribute('top', y * 31 + "px");
    tile.setAttribute('left', x * 31 + "px");
    container.appendChild(tile);
  });
});

function updatePacmanSprite() {
  pacman.style.backgroundImage = `url(${pacmanSprites[direction][currentSpriteIndex]})`;
  currentSpriteIndex = (currentSpriteIndex + 1) % pacmanSprites[direction].length;
}

function animateDeath() {
  let deathInterval = setInterval(() => {
    pacman.style.backgroundImage = `url(${pacmanSprites.dying[currentSpriteIndex]})`;
    currentSpriteIndex++;
    if (currentSpriteIndex === pacmanSprites.dying.length) {
      clearInterval(deathInterval);
      resetGame();
    }
  }, 100);
  // AQUI VOCÊ PRECISA INCLUIR A MENSAGEM DE GAME OVER!!
}

function movePacman(dir) {
  if (isDead) return;
  let nextX = pacX;
  let nextY = pacY;
  switch (dir) {
    case "ArrowUp": nextY--; direction = 'up'; break;
    case "ArrowDown": nextY++; direction = 'down'; break;
    case "ArrowLeft": nextX--; direction = 'left'; break;
    case "ArrowRight": nextX++; direction = 'right'; break;
  }
  if (
    nextY >= 0 &&
    nextY < mazeMap.length &&
    nextX >= 0 &&
    nextX < mazeMap[0].length &&
    mazeMap[nextY][nextX] !== 4
  ) {
    pacX = nextX;
    pacY = nextY;
    pacman.style.left = pacX * 31 + "px";
    pacman.style.top = pacY * 31 + "px";
    pacman.setAttribute('left', pacX * 31 + "px");
    pacman.setAttribute('top', pacY * 31 + "px");
    updatePacmanSprite();
    checkPelletCollision();
  }  
}

function contaPellet(){
  let contadorPellets = (document.querySelectorAll(".pellet, .power-pellet").length);
  // AQUI VOCÊ DEVE VERIFICAR SE FOR === 0 SIGNIFICA QUE O JOGADOR VENCEU!!! Tem que mostrar a mensagem e resetar o game em sequência

}

function checkPelletCollision() {
  const tiles = document.querySelectorAll(".tile");
  let pacCurrentPos = document.getElementById("pacman");
  let leftPacman = pacCurrentPos.getAttribute("left");
  let topPacman = pacCurrentPos.getAttribute("top");  
  tiles.forEach(tile =>{
    let leftTile = tile.getAttribute("left");
    let topTile = tile.getAttribute("top");
    if(leftTile===leftPacman && topTile===topPacman){
      if (tile.classList.contains("pellet")) {
        tile.classList.remove("pellet");
        tile.classList.add("empty");
        contaPellet();
      }
      if (tile.classList.contains("power-pellet")) {
        tile.classList.remove("power-pellet");
        tile.classList.add("empty");
        // AQUI VOCÊ TEM QUE ACIONAR O EFEITO DA POWER PELLET 
        contaPellet();
      }
    }
  });
}

function resetGame() {
  pacX = 1;
  pacY = 1;
  const ghosts = document.querySelectorAll('.ghost');
  ghosts.forEach(ghost => ghost.remove());

  createGhost("blinky", 1);
  createGhost("pinky", 1);
  createGhost("inky", 2);
  createGhost("clyde", 2);

  ghostInGhostZone = {
    blinky: true,
    pinky: true,
    inky: true,
    clyde: true
  };

  pacman.style.left = pacX * 31 + "px";
  pacman.style.top = pacY * 31 + "px";
  isDead = false;
  currentSpriteIndex = 0;
}

document.addEventListener("keydown", (e) => {
  if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.key)) {
    movePacman(e.key);
  }
});

updatePacmanSprite();
setInterval(checkCollisionGhosts, 100);



